worked on this for like AWHILE lost all the files some months back then remade it.
 and hopefully it passes spent a'lot of time working on it thanks. reWROTE ALOT of it cause of what i learned in my
  advanced css and html module the responsive website module? the one before this one . might look like i did it really fast but ive had it written up and basically finished for a while. thanks. signed by nate phelps
